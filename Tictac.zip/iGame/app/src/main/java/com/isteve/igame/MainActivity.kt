package com.isteve.igame

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.isteve.igame.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var mBinding: ActivityMainBinding
    private var player = "p1"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        mBinding.btnreset.setOnClickListener {
            reset()
        }

        mBinding.b1.setOnClickListener {
            buttonClick(mBinding.b1)
        }

        mBinding.b2.setOnClickListener {
            buttonClick(mBinding.b2)
        }

        mBinding.b3.setOnClickListener {
            buttonClick(mBinding.b3)
        }
        mBinding.b4.setOnClickListener {
            buttonClick(mBinding.b4)
        }
        mBinding.b5.setOnClickListener {
            buttonClick(mBinding.b5)
        }
        mBinding.b6.setOnClickListener {
            buttonClick(mBinding.b6)
        }
        mBinding.b7.setOnClickListener {
            buttonClick(mBinding.b7)
        }
        mBinding.b8.setOnClickListener {
            buttonClick(mBinding.b8)
        }
        mBinding.b9.setOnClickListener {
            buttonClick(mBinding.b9)
        }
    }

    private fun reset() {
        mBinding.b1.text = ""
        mBinding.b2.text = ""
        mBinding.b3.text = ""
        mBinding.b4.text = ""
        mBinding.b5.text = ""
        mBinding.b6.text = ""
        mBinding.b7.text = ""
        mBinding.b8.text = ""
        mBinding.b9.text = ""
        mBinding.b1.isEnabled = true
        mBinding.b2.isEnabled = true
        mBinding.b3.isEnabled = true
        mBinding.b4.isEnabled = true
        mBinding.b5.isEnabled = true
        mBinding.b6.isEnabled = true
        mBinding.b7.isEnabled = true
        mBinding.b8.isEnabled = true
        mBinding.b9.isEnabled = true
    }

    private fun buttonClick(btn: Button) {
        if (btn.text == "") {
            if (player == "p1") {
                player = "p2"
                btn.text = "X"
            } else {
                player = "p1"
                btn.text = "0"
            }
        }
        win()
    }

    @SuppressLint("SetTextI18n")
    private fun win() {
        if ((mBinding.b1.text == "X" && mBinding.b2.text == "X" && mBinding.b3.text == "X")
            || (mBinding.b4.text == "X" && mBinding.b5.text == "X" && mBinding.b6.text == "X")
            || (mBinding.b7.text == "X" && mBinding.b8.text == "X" && mBinding.b9.text == "X")
            || (mBinding.b1.text == "X" && mBinding.b5.text == "X" && mBinding.b9.text == "X")
            || (mBinding.b3.text == "X" && mBinding.b5.text == "X" && mBinding.b7.text == "X")
            || (mBinding.b1.text == "X" && mBinding.b4.text == "X" && mBinding.b7.text == "X")
            || (mBinding.b2.text == "X" && mBinding.b5.text == "X" && mBinding.b8.text == "X")
            || (mBinding.b3.text == "X" && mBinding.b6.text == "X" && mBinding.b9.text == "X")
        ) {
            mBinding.textReslt.text = "X Won!"
            toast("X won the Game")
            disableBtn()

        } else  if ((mBinding.b1.text == "0" && mBinding.b2.text == "0" && mBinding.b3.text == "0")
            || (mBinding.b4.text == "0" && mBinding.b5.text == "0" && mBinding.b6.text == "0")
            || (mBinding.b7.text == "0" && mBinding.b8.text == "0" && mBinding.b9.text == "0")
            || (mBinding.b1.text == "0" && mBinding.b5.text == "0" && mBinding.b9.text == "0")
            || (mBinding.b3.text == "0" && mBinding.b5.text == "0" && mBinding.b7.text == "0")
            || (mBinding.b1.text == "0" && mBinding.b4.text == "0" && mBinding.b7.text == "0")
            || (mBinding.b2.text == "0" && mBinding.b5.text == "0" && mBinding.b8.text == "0")
            || (mBinding.b3.text == "0" && mBinding.b6.text == "0" && mBinding.b9.text == "0")
        ) {
            mBinding.textReslt.text = "0 won!"
            toast("0 won the Game")
            disableBtn()
        }
        else{
            if (mBinding.b1.text != "" && mBinding.b2.text != "" && mBinding.b3.text != "" && mBinding.b4.text != ""
                &&  mBinding.b5.text != "" && mBinding.b6.text != ""
                &&  mBinding.b7.text != "" && mBinding.b8.text!= ""
                &&   mBinding.b9.text!= "")
                toast("Game Tie")
        }

    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun disableBtn() {
        mBinding.b1.isEnabled = false
        mBinding.b2.isEnabled = false
        mBinding.b3.isEnabled = false
        mBinding.b4.isEnabled = false
        mBinding.b5.isEnabled = false
        mBinding.b6.isEnabled = false
        mBinding.b7.isEnabled = false
        mBinding.b8.isEnabled = false
        mBinding.b9.isEnabled = false
    }
}

